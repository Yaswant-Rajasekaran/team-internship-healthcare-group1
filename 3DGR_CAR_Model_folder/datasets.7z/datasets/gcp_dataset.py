import os
import torch
from torch.utils.data import Dataset
import numpy as np

class GCPDataset(Dataset):
    def __init__(self, projections_dir, M_dir, split_txt, transform=None):
        self.proj_dir = projections_dir
        self.M_dir = M_dir
        self.transform = transform
        with open(split_txt, 'r') as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]
        self.raw_ids = lines

    def __len__(self):
        return len(self.raw_ids)

    def __getitem__(self, idx):
        raw = self.raw_ids[idx]  
        parts = raw.split("_")
        vid = parts[0]          
        angle = parts[1]        

        img_path = os.path.join(self.proj_dir, f"{vid}_{angle}.npy")
        image_np = np.load(img_path).astype(np.float32)

        img = (image_np - image_np.min()) / (image_np.max() - image_np.min() + 1e-8)
        img = torch.from_numpy(img).unsqueeze(0)  

        M_path = os.path.join(self.M_dir, f"{vid}_{angle}_M.npy")
        M_np = np.load(M_path).astype(np.float32)
        M = torch.from_numpy(M_np)  

        if self.transform:
            img, M = self.transform(img, M)

        return {"image": img, "M": M}
