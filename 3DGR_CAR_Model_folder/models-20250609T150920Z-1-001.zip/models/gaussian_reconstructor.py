import torch
import torch.nn as nn
import torch.optim as optim
from tqdm import trange
import numpy as np

class GaussianReconstructor(nn.Module):
    def __init__(self, init_mu: torch.Tensor, init_sigma: float = 1.0, init_intensity: float = 0.1, device="cuda"):
        super().__init__()
        self.device = device
        n_gaussians = init_mu.shape[0]

        self.centers = nn.Parameter(init_mu.clone().to(device))

        init_log_sigma = torch.log(torch.tensor(init_sigma, dtype=torch.float32))
        sigma_tensor = torch.full((n_gaussians,1), init_log_sigma, device=device)
        self.log_sigma = nn.Parameter(sigma_tensor)

        init_log_intensity = torch.log(torch.tensor(init_intensity, dtype=torch.float32))
        intensity_tensor = torch.full((n_gaussians,1), init_log_intensity, device=device)
        self.log_intensity = nn.Parameter(intensity_tensor)

        grid = torch.stack(torch.meshgrid(
            torch.arange(128, dtype=torch.float32, device=device),
            torch.arange(128, dtype=torch.float32, device=device),
            torch.arange(128, dtype=torch.float32, device=device),
            indexing="ij"
        ), dim=-1) 
        self.register_buffer("coords", grid)

    def forward(self):
        N = self.centers.shape[0]
        sigma = torch.exp(self.log_sigma).view(N)      
        I = torch.exp(self.log_intensity).view(N)      

        diff = self.coords.unsqueeze(0) - self.centers.view(N,1,1,1,3)
        dist2 = (diff ** 2).sum(-1)                  

        sigma_squared = (sigma ** 2).view(N,1,1,1)            
        exponent = torch.exp(-0.5 * dist2 / sigma_squared)    

        patch_all = I.view(N,1,1,1) * exponent         
        V = patch_all.sum(dim=0)                      

        return V.unsqueeze(0).unsqueeze(0)            

    def optimize(self, real_projs, real_masks, angles, num_iter=3000, lr=1e-3):
        optimizer = optim.Adam([self.mu, self.log_sigma, self.log_intensity], lr=lr)
        loop = trange(1, num_iter+1, desc="Optimization 3DGR")

        for it in loop:
            optimizer.zero_grad()
            volume = self.forward()  

            loss_total = torch.tensor(0.0, device=self.device)

            for proj_real, mask_real, angle in zip(real_projs, real_masks, angles):
                sim_proj = project_volume(volume, angle)  
                proj_gt = proj_real.unsqueeze(0).unsqueeze(0)   
                mask = mask_real.unsqueeze(0).unsqueeze(0)      

                l2   = torch.mean((sim_proj - proj_gt)**2)
                cont = torch.mean(((sim_proj - proj_gt)*mask)**2)
                loss_total += 0.5*l2 + 0.5*cont

            loss_total.backward()
            optimizer.step()

            if it % 50 == 0 or it == num_iter:
                loop.set_postfix({"loss": loss_total.item()})

        print("Otimização 3DGR concluída.")

def project_volume(volume_3d: torch.Tensor, angle_deg: float) -> torch.Tensor:
    if angle_deg == 0:
        proj = torch.sum(volume_3d, dim=4)  
    elif angle_deg == 90:
        proj = torch.sum(volume_3d, dim=3) 
    else:
        vol_np = volume_3d.detach().cpu().numpy()[0,0]  
        k = int(angle_deg / 90) % 4
        rot = np.rot90(vol_np, k=k, axes=(1,2))
        proj_np = np.sum(rot, axis=0)
        proj = torch.from_numpy(proj_np).unsqueeze(0).unsqueeze(0).to(volume_3d.device)

    mx = proj.max()
    if mx > 0:
        proj = proj / mx
    return proj
